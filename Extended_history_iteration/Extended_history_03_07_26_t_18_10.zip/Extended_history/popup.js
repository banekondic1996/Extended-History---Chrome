// popup.js — fast, reads storage directly (no message round-trip for history list)

let _searchTimer = null;

function tryDomain(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
}

function favUrl(domain) {
    return `https://www.google.com/s2/favicons?sz=16&domain=${encodeURIComponent(domain)}`;
}

// ── Theme & Popup Settings ────────────────────────────────────────────────────
chrome.storage.local.get('eh_settings', r => {
    const s = r.eh_settings || {};
    document.documentElement.setAttribute('data-theme', s.theme || 'dark');
    if (s.accentColor)  document.documentElement.style.setProperty('--accent',  s.accentColor);
    if (s.accentColor2) document.documentElement.style.setProperty('--accent2', s.accentColor2);

    // Popup-specific settings
    if (s.popupShowSearch === false) document.querySelector('.search-bar').style.display = 'none';
    if (s.popupShowTabs   === false) document.getElementById('tabsRow').style.display    = 'none';
    if (s.popupHeight) {
        document.querySelector('.content').style.maxHeight = s.popupHeight + 'px';
        document.querySelector('.search-list').style.maxHeight = s.popupHeight + 'px';
    }
});

// ── Header "Open" button ──────────────────────────────────────────────────────
document.getElementById('openBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'history.html' });
});

// ── Tab switcher ──────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        document.getElementById(`panel-${tabName}`).classList.add('active');
    });
});

// ── Footer panel buttons ──────────────────────────────────────────────────────
document.querySelectorAll('.flink[data-panel]').forEach(btn => {
    btn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'history.html#' + btn.dataset.panel });
    });
});

// ── Helper: build a row <a> element ──────────────────────────────────────────
function makeRow(url, title, timeText, onLeftClick) {
    const dom = tryDomain(url);

    // Use <a> so Chrome's native context menu provides open in new tab / copy URL etc.
    const row = document.createElement('a');
    row.className = 'ritem';
    row.href = url;
    row.title = (title || url) + '\n' + url; // native tooltip

    // Left click: use extension navigation rather than default link navigation
    row.addEventListener('click', (ev) => {
        ev.preventDefault();
        if (ev.button === 0) onLeftClick();
    });

    const img = document.createElement('img');
    img.className = 'rfav';
    img.loading   = 'lazy';
    img.src       = favUrl(dom);
    img.addEventListener('error', () => { img.style.visibility = 'hidden'; });

    const body  = document.createElement('div');
    body.className = 'rbody';

    const titleEl = document.createElement('div');
    titleEl.className   = 'rtitle';
    titleEl.textContent = title || url;

    body.appendChild(titleEl);

    const time = document.createElement('div');
    time.className   = 'rtime';
    time.textContent = timeText;

    row.appendChild(img);
    row.appendChild(body);
    row.appendChild(time);
    return row;
}

// ── Search Functionality ──────────────────────────────────────────────────────
document.getElementById('searchInput').addEventListener('input', (e) => {
    const query = e.target.value.trim();
    const clearBtn = document.getElementById('searchClear');

    clearBtn.classList.toggle('visible', !!query);
    clearTimeout(_searchTimer);

    if (!query) {
        closeSearchOverlay();
        return;
    }

    document.getElementById('searchResults').innerHTML = '<div class="loading">Searching...</div>';
    openSearchOverlay();

    _searchTimer = setTimeout(() => {
        performSearch(query);
    }, 300);
});

document.getElementById('searchClear').addEventListener('click', () => {
    document.getElementById('searchInput').value = '';
    document.getElementById('searchClear').classList.remove('visible');
    closeSearchOverlay();
    document.getElementById('searchInput').focus();
});

function openSearchOverlay() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay.classList.contains('active')) return;
    requestAnimationFrame(() => {
        overlay.classList.add('active');
        document.getElementById('tabsRow').classList.add('hidden');
    });
}

function closeSearchOverlay() {
    document.getElementById('searchOverlay').classList.remove('active');
    document.getElementById('tabsRow').classList.remove('hidden');
}

function performSearch(query) {
    const resultsEl = document.getElementById('searchResults');

    chrome.runtime.sendMessage({
        type: 'SEARCH',
        query: query,
        mode: 'all',
        limit: 100
    }, (response) => {
        if (chrome.runtime.lastError) {
            resultsEl.innerHTML = '<div class="empty">Search error</div>';
            return;
        }

        const matches = response.entries || [];

        if (!matches.length) {
            resultsEl.innerHTML = '<div class="empty">No results found</div>';
            return;
        }

        resultsEl.innerHTML = '';
        for (const e of matches) {
            const t = new Date(e.visitTime).toLocaleDateString([], { month: 'short', day: 'numeric' });
            const row = makeRow(e.url, e.title, t, () => chrome.tabs.create({ url: e.url }));
            resultsEl.appendChild(row);
        }
    });
}

// ── Recent history — read today's history only for fast loading ───────────────
function loadTodayHistory() {
    chrome.storage.local.get('eh_today_history', r => {
        const entries = (r.eh_today_history || []).slice().sort((a, b) => b.visitTime - a.visitTime).slice(0, 15);
        const el = document.getElementById('recent');

        if (!entries.length) {
            el.innerHTML = '<div class="empty">No history yet today</div>';
            return;
        }

        el.innerHTML = '';
        for (const e of entries) {
            const t = new Date(e.visitTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const row = makeRow(e.url, e.title, t, () => chrome.tabs.create({ url: e.url }));
            el.appendChild(row);
        }
    });
}

// ── Recent closed tabs ────────────────────────────────────────────────────────
function loadRecentTabs() {
    chrome.sessions.getRecentlyClosed({ maxResults: 15 }, sessions => {
        const el = document.getElementById('recentTabs');

        if (!sessions || !sessions.length) {
            el.innerHTML = '<div class="empty">No recently closed tabs</div>';
            return;
        }

        const tabs = [];
        for (const session of sessions) {
            if (session.tab) {
                tabs.push({
                    url: session.tab.url,
                    title: session.tab.title,
                    sessionId: session.tab.sessionId,
                    lastModified: session.lastModified
                });
            } else if (session.window) {
                for (const tab of session.window.tabs || []) {
                    tabs.push({
                        url: tab.url,
                        title: tab.title,
                        sessionId: tab.sessionId,
                        lastModified: session.lastModified
                    });
                }
            }
        }

        if (!tabs.length) {
            el.innerHTML = '<div class="empty">No recently closed tabs</div>';
            return;
        }

        const validTabs = tabs.filter(tab => {
            if (!tab.lastModified) return false;
            const ageInDays = (Date.now() - tab.lastModified * 1000) / (1000 * 60 * 60 * 24);
            return ageInDays >= 0 && ageInDays <= 30;
        }).sort((a, b) => b.lastModified - a.lastModified);

        if (!validTabs.length) {
            el.innerHTML = '<div class="empty">No recently closed tabs</div>';
            return;
        }

        el.innerHTML = '';
        for (const tab of validTabs.slice(0, 15)) {
            const timeAgo = getTimeAgo(tab.lastModified);
            const onLeftClick = tab.sessionId
                ? () => chrome.sessions.restore(tab.sessionId)
                : () => chrome.tabs.create({ url: tab.url });
            const row = makeRow(tab.url, tab.title, timeAgo, onLeftClick);
            el.appendChild(row);
        }
    });
}

// Helper: format time ago
function getTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp * 1000) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
}

// Load initially
loadRecentTabs();
loadTodayHistory();

// Auto-refresh on storage change
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.eh_today_history) {
        loadTodayHistory();
    }
});

// Refresh closed tabs list when a tab/window closes
chrome.tabs.onRemoved.addListener(() => { setTimeout(loadRecentTabs, 100); });
chrome.windows.onRemoved.addListener(() => { setTimeout(loadRecentTabs, 100); });

// Polling fallback
let lastCount = 0;
setInterval(() => {
    chrome.storage.local.get('eh_today_history', r => {
        const entries = r.eh_today_history || [];
        if (entries.length !== lastCount) {
            lastCount = entries.length;
            loadTodayHistory();
        }
    });
}, 2000);
// ── Right-click Sessions button → export latest session as HTML ───────────────
(function () {
  function tryDomainLocal(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
  }
  function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function exportSessionAsHtmlPopup(label, tabs) {
    const validTabs = tabs.filter(t => t.url);

    const windowIds = [...new Set(validTabs.map(t => t.windowId).filter(Boolean))];
    const hasMultiWindow = windowIds.length > 1;

    let linksHtml = '';
    if (hasMultiWindow) {
      const windowMap = new Map();
      for (const t of validTabs) {
        const wid = t.windowId || 'unknown';
        if (!windowMap.has(wid)) windowMap.set(wid, []);
        windowMap.get(wid).push(t);
      }
      let winIndex = 1;
      for (const [wid, winTabs] of windowMap) {
        linksHtml += `<div class="win-header">Window ${winIndex} <span class="win-count">${winTabs.length} tab${winTabs.length !== 1 ? 's' : ''}</span></div>`;
        linksHtml += winTabs.map(t => {
          const dom = tryDomainLocal(t.url);
          return `<a href="${esc(t.url)}"><img class="fav" src="https://www.google.com/s2/favicons?sz=16&domain=${encodeURIComponent(dom)}" loading="lazy" onerror="this.style.display='none'"/><span class="title">${esc(t.title||t.url)}</span><span class="domain">${esc(dom)}</span></a>`;
        }).join('');
        winIndex++;
      }
    } else {
      linksHtml = validTabs.map(t => {
        const dom = tryDomainLocal(t.url);
        return `<a href="${esc(t.url)}"><img class="fav" src="https://www.google.com/s2/favicons?sz=16&domain=${encodeURIComponent(dom)}" loading="lazy" onerror="this.style.display='none'"/><span class="title">${esc(t.title||t.url)}</span><span class="domain">${esc(dom)}</span></a>`;
      }).join('');
    }

    const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/><title>Session – ${esc(label)}</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:system-ui,sans-serif;background:#0d0d10;color:#f0eee8;padding:40px 32px}
h1{font-size:1.3rem;font-weight:700;color:#3b9eff;margin-bottom:4px}.meta{font-size:.78rem;color:#a09eb0;margin-bottom:28px}
.links{display:flex;flex-direction:column;gap:3px}a{display:flex;align-items:center;gap:10px;padding:9px 14px;border-radius:8px;text-decoration:none;color:#f0eee8;background:#18181f;border:1px solid rgba(255,255,255,.06);transition:background .1s}
a:hover{background:#1f1f28}.fav{width:16px;height:16px;border-radius:3px;flex-shrink:0}.title{flex:1;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.domain{font-size:.7rem;color:#a09eb0;flex-shrink:0;font-family:monospace}
.win-header{font-size:.75rem;font-weight:700;color:#3b9eff;padding:16px 4px 6px;display:flex;align-items:center;gap:8px;border-bottom:1px solid rgba(59,158,255,.2);margin-bottom:4px}
.win-header:first-child{padding-top:0}.win-count{font-weight:400;color:#a09eb0}
footer{margin-top:36px;font-size:.7rem;color:#5a5870}</style></head>
<body><h1>📋 ${esc(label)}</h1><div class="meta">${validTabs.length} tabs · Exported ${new Date().toLocaleString()}</div>
<div class="links">${linksHtml}</div><footer>Exported by Extended History</footer></body></html>`;

    Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(new Blob([html], { type: 'text/html' })),
      download: `session_${new Date().toISOString().slice(0,10)}.html`
    }).click();
  }

  const sessionsBtn = document.querySelector('.flink[data-panel="sessions"]');
  if (!sessionsBtn) return;

  sessionsBtn.addEventListener('contextmenu', (ev) => {
    ev.preventDefault();
    chrome.runtime.sendMessage({ type: 'GET_SESSIONS' }, (response) => {
      if (chrome.runtime.lastError || !response) return;
      const { sessions, current } = response;

      // Prefer most recent past session; fall back to current
      const target = sessions && sessions.length ? sessions[sessions.length - 1] : null;
      const tabs = target ? target.tabs : (current ? current.tabs.filter(t => t.url && t.closed === null) : null);

      if (!tabs || !tabs.length) {
        // No session data — just open the page
        chrome.tabs.create({ url: 'history.html#sessions' });
        return;
      }

      const label = target
        ? new Date(target.start).toLocaleString(undefined, { weekday:'short', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' })
        : 'Current Session';

      exportSessionAsHtmlPopup(label, tabs);
    });
  });
})();